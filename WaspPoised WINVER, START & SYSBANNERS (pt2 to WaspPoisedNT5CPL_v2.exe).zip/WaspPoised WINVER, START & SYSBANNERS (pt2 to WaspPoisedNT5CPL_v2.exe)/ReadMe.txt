WINDOWS 2000 PROFESSIONAL CONTROL PANEL PORT, SYSBANNERS, WINVER, AND START BUTTON .ZIP
----------------------------------------------------------------------------------------

BOOT SAFE MODE FOR BEST RESULTS
-This .zip can upgrade your install of WaspPoisedNT5CPL_v2.exe
-navigate to c:\windows\ 
-move c:\windows\explorer.exe to your desktop, then in a short time frame move [.zip]\explorer.exe in it's place at c:\windows\
-navigate to c:\windows\system32\
-move msgina.dll to your desktop, then in a short time frame move [.zip]\system32\msgina.dll in it's place at c:\windows\system32\
-move shell32.dll to your desktop, then in a short time frame move [.zip]\system32\shell32.dll in it's place at c:windows\system32\

 [disable the themes service in services.msc]
-Install complete for windows 2000 start button/banner, winver/logon banners and NT5.0 Build 2195 displaying in Winver
 
-----------------------------------------------------------------------------------------

To Get Closer to the Windows 2000 Boot Screen, use the .res files and replace the .bmp in your ntoskrnl.exe and ntkrnlpa.exe
(Both files are located at c:\windows\system32\) 

-----------------------------------------------------------------------------------------
disabling Windows File Protection:
  -press win key + R
  -run 'regedit'
  -navigate to HKEY_LOCAL_MACHINE/SOFTWARE/Microsoft/Windows NT/Current Version/Winlogon
  -In the right hand pane find 'SFCDisable' (REG_DWORD Value)
  -open/double-click SFCDisable
  -Change the value data to '1'
  -reboot
  -open services.msc in run (Win Key + R)
  -disable Cryptographic Services and stop the service
  -disable Protected Storage and stop the service
    [watch the services.msc page routinely for a minute or two, the 
    Cryptographic Services service might start up again very quickly despite 
    being disabled, just stop the service again and eventually it won't 
    start again]
  -go to c:\windows\system32
  -move dllcache folder to your desktop, this is a hidden folder
  -hit serch files, search 'SFC'
  -delete SFC.exe sfcfiles.dll and sfc.dll
  -if windows file protection rewrites these files, check services.msc to 
   see if Cryptographic Services has started again, as this is the main 
   cause 
